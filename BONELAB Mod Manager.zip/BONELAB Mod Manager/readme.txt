This is a mod manager for BONELAB. If for some reason the mod.io Networker does not work, its a great alterative.

This program has the following features:

1. Mod installing
2. Mod Updating
3. Mod Conflict Checker

Also. This mod manager is build off of tkinter, which means it looks like shit.
But it functions as it should.

PATCH NOTES:

1.0.0:
Initial Release


JOIN MY DISCORD TO REPORT BUGS AND SUGGESTIONS ABOUT THIS MOD!

https://discord.gg/vRyWkXW5Vh


